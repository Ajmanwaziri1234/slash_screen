package com.example.slash_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
